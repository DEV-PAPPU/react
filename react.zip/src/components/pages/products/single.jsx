import React, {useState, useEffect} from 'react';

import { useParams} from "react-router-dom";

import axios from 'axios';
// import {SET_PRODUCT} from "../../../actions/index"
// import { useSelector, useDispatch } from 'react-redux';


const Single = () => {

    let {slug} = useParams();
    // const dispatch = useDispatch();

    const [loading, setLoading] = useState(true);


    const [username, setUsername] =  useState([]);

    const [product, setProduct] = useState([]);
    // const single_data = useSelector((state) => state.PRODUCTSINGLE);



        useEffect(() => {

           

            axios.get(`product-single/${slug}`).then(res=>{
                if(res.status === 200)
                {

                    setUsername(res.data);

                    console.log("username state ----" , username)


                    // console.log("test user state --", username);

                    console.log("single product ----" , res.data)
                    console.log("single product type ----" , typeof(res.data))
                                        
                    setProduct('pappu');

                    console.log("state data ----" , product)
                    console.log("single product ----" , res.data)




                    setLoading(false);
                                     

                    // dispatch(SET_PRODUCT(res.data));
                }
            });

        }, []);


        if(loading)
        {
            return <h4 className="container px-20 py-10">Loading  Data...</h4>
        }

    return (

        <div className="product-component container px-20 py-10">
            
            <h3>Mapping plm</h3>                          


         </div>
    );
}


export default Single;
